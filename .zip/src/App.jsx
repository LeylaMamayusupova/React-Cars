import "./App.css";

function App() {
  return (
    <div className="container">
      <div className="header">
        <div className="hero">
          <h1>BOXCARS</h1>
          <div className="hero1">
            <ul>
              <a href=""> Home</a>
              <a href="">Listings</a>
              <a href="">Blog</a>
              <a href="">Pages</a>
              <a href="">About</a>
              <a href="">Contact</a>
              <a href="">Sign in</a>
            </ul>
            <button>Submit Listing</button>
          </div>
        </div>
        <div className="main">
          <div className="info">
            <p>Find cars for sale and for rent near you</p>
            <h1>Find Your Perfect Car</h1>
            <button className="form">
              Any Makes Any Models Prices: All Prices{" "}
              <input className="in" type="text" placeholder="Search Cars" />
            </button>
            <p className="or">Or Browse Featured Model</p>
            <div className="buts">
              <button>Suv</button>
              <button>Sedan</button>
              <button>Hatchback</button>
              <button>Coupe</button>
              <button>Hybrid</button>
            </div>
          </div>
        </div>
      </div>
      <div className="page1">
        <div className="explore">
          <h1>Explore Our Premium Brands</h1>
          <p>Show All Brands</p>
        </div>
        <div className="flexbox">
          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/b1.jpg.png" alt="" />
            </div>
            <p>Audi</p>
          </div>
          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/b2.jpg.png" alt="" />
            </div>
            <p>BMW</p>
          </div>
          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/b3.jpg.png" alt="" />
            </div>
            <p>Ford</p>
          </div>
          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/b4.jpg.png" alt="" />
            </div>
            <p>Mercedes Benz</p>
          </div>

          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/b5.jpg.png" alt="" />
            </div>
            <p>Peugeot</p>
          </div>

          <div className="flex">
            <div className="main_img">
              <img src="public/imgs/Link(1).png" alt="" />
            </div>
          </div>
        </div>
        <div className="type">
          <div className="vehicle">
            <h1>Explore All Vehicles</h1>
            <p>View All</p>
          </div>
          <div className="type1">
            <h3>In Stock</h3>
            <h3>New Cars</h3>
            <h3>Used Cars</h3>
          </div>
          <div className="box">
            <div className="box1">
              <div className="img">
                <img src="public/imgs/Container.png" alt="" />
              </div>
              <p className="shelby">Ford Transit – 2021</p>
              <p className="shelby">4.0 D5 PowerPulse Momentum 5dr AW… Geartronic Estate</p>
              <div className="dissel">
                <img src="public/imgs/Vector(4).png" alt="" />
                <img src="public/imgs/Icon(1).svg" alt="" />
                <img src="public/imgs/Icon(1).png" alt="" />
              </div>
              <div className="dissel1">
                <p>2500 Miles</p>
                <p>Diesel</p>
                <p>Manual</p>
              </div>
              <div className="foot">
                <p className="price">$22,000</p>
                <p>View Details</p>
              </div>
            </div>
            <div className="box1">
              <div className="img">
                <img src="public/imgs/Container(1).png" alt="" />
              </div>
              <p className="shelby">Ford Transit – 2021</p>
              <p className="shelby">4.0 D5 PowerPulse Momentum 5dr AW… Geartronic Estate</p>
              <div className="dissel">
                 <img src="public/imgs/Vector(4).png" alt="" />
              <img src="public/imgs/Icon(1).svg" alt="" />
                <img src="public/imgs/Icon(1).png" alt="" />
              </div>
              <div className="dissel1">
                <p>50 Miles</p>
                <p>Petrol</p>
                <p>Automatic</p>
              </div>
              <div className="foot">
                <p className="price">$95,000</p>
                <p>View Details</p>
              </div>
            </div>

            <div className="box1">
              <div className="img">
                <img src="public/imgs/Container(2).png" alt="" />
              </div>
              <p className="shelby">Ford Transit – 2021</p>
              <p className="shelby">4.0 D5 PowerPulse Momentum 5dr AW… Geartronic Estate</p>
              <div className="dissel">
             <img src="public/imgs/Vector(4).png" alt="" />
                <img src="public/imgs/Icon(1).svg" alt="" />
                <img src="public/imgs/Icon(1).png" alt="" />
              </div>
              <div className="dissel1">
                <p>100 Miles</p>
                <p>Petrol</p>
                <p>Automatic</p>
              </div>
              <div className="foot">
                <p className="price">$58,000</p>
                <p>View Details</p>
              </div>
            </div>

            <div className="box1">
              <div className="img">
                <img src="public/imgs/Container(3).png" alt="" />
              </div>
              <p className="shelby">Ford Transit – 2021</p>
              <p className="shelby">4.0 D5 PowerPulse Momentum 5dr AW… Geartronic Estate</p>
              <div className="dissel">
                <img src="public/imgs/Vector(4).png" alt="" />
                <img src="public/imgs/Icon(1).svg" alt="" />
                <img src="public/imgs/Icon(1).png" alt="" />
              </div>
              <div className="dissel1">
                <p>15000 Miles</p>
                <p>Petrol</p>
                <p>Automatic</p>
              </div>
              <div className="foot">
                <p className="price">$45,000</p>
                <p>View Details</p>
              </div>
            </div>
          

          

            
          </div>
        </div>
      </div>
      <div className="page2">
        <div className="section">
          <div className="redcar">
            <img src="" alt="" />
          </div>
          <div className="information">
            <h1>Get A Fair Price For Your Car Sell To Us Today</h1>
            <p>
              We are committed to providing our customers with exceptional
              service, competitive pricing, and a wide range of.
            </p>
            <p>
              <i class="fa-solid fa-check"></i> We are the UK’s largest
              provider, with more patrols in more places
            </p>
            <p>
              <i class="fa-solid fa-check"></i> You get 24/7 roadside assistance
            </p>
            <p>
              <i class="fa-solid fa-check"></i> We fix 4 out of 5 cars at the
              roadside
            </p>
            <button>
              Get Started
              <i class="fa-solid fa-up-right-and-down-left-from-center"></i>
            </button>
          </div>
        </div>
        <div className="km">
          <div className="hour">
            <h2>836M</h2>
            <p>CARS FOR SALE</p>
          </div>
          <div className="hour">
            <h2>738M</h2>
            <p>DEALER REVIEWS</p>
          </div>
          <div className="hour">
            <h2>100M</h2>
            <p>VISITORS PER DAY</p>
          </div>
          <div className="hour">
            <h2>238M</h2>
            <p>VERIFIED DEALERS</p>
          </div>
        </div>
        <div className="deep_info">
          <div className="deep">
            <div className="service">
              <img src="" alt="" />
            </div>
            <h3>Special Financing Offers</h3>
            <p>
              Our stress-free finance department that can find financial
              solutions to save you money.
            </p>
          </div>

          <div className="deep">
            <div className="service">
              <img src="" alt="" />
            </div>
            <h3>Trusted Car Dealership</h3>
            <p>
              Our stress-free finance department that can find financial
              solutions to save you money.
            </p>
          </div>

          <div className="deep">
            <div className="service">
              <img src="" alt="" />
            </div>
            <h3>Transparent Pricing</h3>
            <p>
              Our stress-free finance department that can find financial
              solutions to save you money.
            </p>
          </div>

          <div className="deep">
            <div className="service">
              <img src="" alt="" />
            </div>
            <h3>Expert Car Service</h3>
            <p>
              Our stress-free finance department that can find financial
              solutions to save you money.
            </p>
          </div>
        </div>
      </div>
      <div className="page3">
        <div className="pop">
          <h1>Popular Makes</h1>
          <p>
            View All
            <i class="fa-solid fa-up-right-and-down-left-from-center"></i>
          </p>
        </div>
        <div className="marka">
          <p>Audi</p>
          <p>Ford</p>
          <p>Mercedes Benz</p>
        </div>
        <div className="section2">
          <div className="section3">
            <div className="audi">
              <img src="" alt="" />
            </div>
            <div className="section4">
              <p>Audi A5 – 2023</p>
              <p>2.0 D5 PowerPulse Momentum 5dr AWD… Geartronic Estate</p>
              <div className="petrol">
                <img src="" alt="" />
                <p>500 Miles</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
